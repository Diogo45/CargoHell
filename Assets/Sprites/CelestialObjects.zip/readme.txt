Free Celestial Objects Pixel Art Pack

A free pack of 30 different celestial objects for your space game!

This pack includes:

- 12 planets (64x64px)
- 4 moons  (32x32px)
- 4 dwarf stars (32x32px)
- 4 asteroids 
- 3 star clusters 
- 2 nebulae
- black hole

---

LICENSE: You can use this asset pack both in free and commercial projects. You may modify it to suit your own needs. Credit is not necessary, but appreciated.

You may not redistribute or resell the assets/ the asset pack!

---

Twitter - https://twitter.com/norma_2d

DeviantArt - https://www.deviantart.com/norma2d

If you like what I do and would like to support me:

Ko-fi - https://ko-fi.com/norma2d 

---
